import readdy
import readdyviewer
from readdy.api.utils import load_trajectory_to_npy

outfile = "data/living_polymers.h5"

n_particles_per_frame, positions, types, ids = load_trajectory_to_npy(outfile)

config = readdyviewer.Configuration()

print(dir(config))

t = readdy.Trajectory(outfile)
entries = t.read()
time, topology_records = t.read_observable_topologies()

print(t.particle_types)


edges = []
for tops in topology_records:
    current_edges = []
    for top in tops:
        for e1, e2 in top.edges:
            if e1 <= e2:
                ix1 = top.particles[e1]
                ix2 = top.particles[e2]
                current_edges.append((ix1, ix2))
    edges.append(current_edges)

config.colors[t.particle_types['Head']] = readdyviewer.Color(.1,.2,.3)
config.radii[t.particle_types['Head']] = 0.5
config.colors[t.particle_types['Tail']] = readdyviewer.Color(0.513, 0.239, 0.105)
config.radii[t.particle_types['Tail']] = 0.3
config.stride = 100
config.smoothing = 1
config.clearcolor = readdyviewer.Color(1,1,1)
config.set_box_size(100,100,100)
config.cutoff = 3.

readdyviewer.watch_npy(positions, types, ids, n_particles_per_frame, config, edges)