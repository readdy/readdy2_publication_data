#!/usr/bin/env python
# coding: utf-8

import numpy as np
import readdy
import matplotlib.pyplot as plt
import os
from collections import defaultdict

"""
System parameters:
- default unit set is nm, ns, kJ/mol
- kT = 2.437 kJ/mol
- self diffusion coefficient D = 2e-3 nm^2/ns
- bond length sigma = 1nm
- bond force constant kappa = 50 kJ/mol / nm^2 (not relevant)
- harmonic equilibrium angle = pi (not relevant)
- volume V = 100^3 nm^3
- rate of breaking a single bond = 5e-6 ns^-1
- spatial bond forming reaction with distance R=1 nm and rate=1 ns^-1
- initially 500 polymers with 4 beads each, if each bead
  has volume of v=4/3 * pi * 0.5^3, then ~1% of volume is occupied
- number density is 2000 particles per 100^3 nm^3 = 2e-3 nm^-3
- transform this to 1M = 1mol/L -> molar concentration of beads = 3.32 millimolar (mM)
- timestep = 1ns
- n_steps = 350000 -> integrated time 350 mus
"""

def perform(n):
    print("***"*15)
    print("perform {}".format(n))
    print("***"*15)
    system = readdy.ReactionDiffusionSystem(box_size=[100, 100, 100])
    
    system.topologies.add_type("Polymer")
    system.add_topology_species("Head", .002)
    system.add_topology_species("Tail", .002)
    
    system.topologies.configure_harmonic_bond("Head", "Tail", force_constant=50, length=1.)
    system.topologies.configure_harmonic_bond("Tail", "Tail", force_constant=50, length=1.)
    system.topologies.configure_harmonic_bond("Head", "Head", force_constant=50, length=1.)
    system.topologies.configure_harmonic_angle("Head", "Tail", "Tail", force_constant=10, equilibrium_angle=np.pi)
    system.topologies.configure_harmonic_angle("Tail", "Tail", "Tail", force_constant=10, equilibrium_angle=np.pi)
    
    
    # dissociation
    def dissociation_rate_function(topology):
        edges = topology.get_graph().get_edges()
        return .000005 * float(len(edges)) if len(edges) > 2 else 0.
    
    
    def dissociation_reaction_function(topology):
        recipe = readdy.StructuralReactionRecipe(topology)
        edges = topology.get_graph().get_edges()
        vertices = topology.get_graph().get_vertices()
    
        # at least a structure like
        # v1 -- v2 -- v3 -- v4
        if len(edges) > 2:
            # find the end particles
            counts = defaultdict(int)
            for e in edges:
                pix1 = e[0].get().particle_index
                pix2 = e[1].get().particle_index
                counts[pix1] += 1
                counts[pix2] += 1
    
                # the end particles are the ones that have exactly one edge leading from/to them
            endpoints = []
            for pix in counts.keys():
                if counts[pix] == 1:
                    endpoints.append(pix)
    
            assert len(endpoints) == 2, "the number of end points should always be 2 but was {} (counts: {})".format(
                len(endpoints),
                counts)
    
            # draw an edge excluding the edges leading to the both ends
            edge_index = np.random.randint(0, len(edges) - 2)
            removed_edge = None
            # for each edge in the graph
            for e in edges:
                pix1 = e[0].get().particle_index
                pix2 = e[1].get().particle_index
                # check if it belongs to one of the end vertices
                if pix1 not in endpoints and pix2 not in endpoints:
                    # if not, reduce edge_index until 0
                    if edge_index == 0:
                        # remove this edge
                        recipe.remove_edge(e)
                        removed_edge = e
                        break
                    else:
                        edge_index -= 1
    
            assert removed_edge is not None
    
            pix1 = removed_edge[0].get().particle_index
            pix2 = removed_edge[1].get().particle_index
    
            assert pix1 not in endpoints
            assert pix2 not in endpoints
    
            # since the edge was removed we now have two topologies and need to set the correct particle types
            recipe.change_particle_type([vix for vix, v in enumerate(vertices) if v.particle_index == pix1][0], "Head")
            recipe.change_particle_type([vix for vix, v in enumerate(vertices) if v.particle_index == pix2][0], "Head")
        else:
            print("this should not have happened")
        return recipe
    
    system.topologies.add_structural_reaction("Polymer", dissociation_reaction_function, dissociation_rate_function)
    
    system.topologies.add_spatial_reaction("Association: Polymer(Head) + Polymer(Head) -> Polymer(Tail--Tail)",
                                           rate=1.0, radius=1.0)
    
    simulation = system.simulation(kernel="CPU")
    
    # randomly place some polymers of length 4
    n_polymers = 500
    for head in range(n_polymers):
        head_position = 80. * np.random.random((1, 3)) - 40.
        offset1 = 2. * np.random.random((1, 3)) - 1.
        offset1 /= np.linalg.norm(offset1)
        tail1 = head_position + offset1
        offset2 = 2. * np.random.random((1, 3)) - 1.
        offset2 /= np.linalg.norm(offset2)
        tail2 = head_position + offset1 + offset2
        offset3 = 2. * np.random.random((1, 3)) - 1.
        offset3 /= np.linalg.norm(offset3)
        head_position2 = head_position + offset1 + offset2 + offset3
    
        top = simulation.add_topology("Polymer", ["Head", "Tail", "Tail", "Head"],
                                      np.array([head_position, tail1, tail2, head_position2]).squeeze())
        top.get_graph().add_edge(0, 1)
        top.get_graph().add_edge(1, 2)
        top.get_graph().add_edge(2, 3)
    
    simulation.output_file = "data/living_polymers.h5"
    simulation.observe.topologies(300)
    simulation.record_trajectory(300)
    simulation.progress_output_stride = 10
    simulation.show_progress = True
    
    timestep = 1.
    if os.path.exists(simulation.output_file):
        os.remove(simulation.output_file)
    simulation.run(350000, timestep)
    
    # read back topologies
    t = readdy.Trajectory(simulation.output_file)
    time, topology_records = t.read_observable_topologies()
    
    # gather average length of topologies for respective time step
    number_of_beads = []
    number_of_beads_std_dev = []
    number_of_topologies = []
    # for each time step
    for topologies in topology_records:
        # gather number of topologies and average number of beads
        number_of_topologies.append(len(topologies))
        current_ns = np.array([len(top.edges) + 1 for top in topologies])
        number_of_beads.append(np.mean(current_ns))
        number_of_beads_std_dev.append(np.std(current_ns))
    number_of_beads = np.array(number_of_beads)
    number_of_beads_std_dev = np.array(number_of_beads_std_dev)
    number_of_topologies = np.array(number_of_topologies)
    
    f, ax = plt.subplots(nrows=1, ncols=1)
    ax.plot(time, number_of_beads)
    ax.set_title('average length')
    ax.set_xlabel('time')
    ax.set_ylabel('# beads')
    # plt.show()
    plt.clf()
    
    np.savez("data/polylen_{}".format(n), times=time, number_of_beads=number_of_beads,
             number_of_beads_std_dev=number_of_beads_std_dev, number_of_topologies=number_of_topologies)
    
    # from IPython.display import YouTubeVideo
    # YouTubeVideo('1fZqbZRQnEQ')

for i in range(15):
    perform(i)

