#!/usr/bin/env python
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import scipy.optimize as so
import pandas as pd
import argparse

plt.style.use("./readdy_manuscript.mplstyle")

"""
The individual scripts (living_polymer.py, ...) generate data in directory 'data/'
This script generates plots from the data using the given style.
"""

parser = argparse.ArgumentParser()
parser.add_argument('--living-polymer', dest='do_living_polymer', action='store_true', default=False)
parser.add_argument('--msd', dest='do_msd', action='store_true', default=False)
parser.add_argument('--cytosolic', dest='do_cytosolic', action='store_true', default=False)


# Utilities
def logarithmic_indices(lower, upper, num):
    assert upper > lower
    assert upper >= 0
    lower_exp = np.log10(lower) if lower > 0 else 0
    upper_exp = np.log10(upper)
    indices = np.logspace(lower_exp, upper_exp, num=num, endpoint=False, dtype=int).tolist()
    if lower == 0:
        indices = [0] + indices
    indices = [indices[0]] + [indices[i] for i in range(1, len(indices)) if indices[i] > indices[i - 1]]
    if indices[-1] >= upper:
        indices.pop()
    return np.array(indices, dtype=int)


def linear_indices(lower, upper, num):
    assert upper > lower
    assert upper >= 0
    indices = np.linspace(lower, upper, num=num, dtype=int).tolist()
    indices = [indices[0]] + [indices[i] for i in range(1, len(indices)) if indices[i] > indices[i - 1]]
    if indices[-1] >= upper:
        indices.pop()
    return np.array(indices, dtype=int)


def logarithmic_indices_of_uneven_values(values, num):
    # e.g. values is an array of times, which are not equidistant
    # one now wants an array that yields `num` indices which would correspond
    # to logarithmically spaced values
    desired_values = np.logspace(np.log10(values[1]), np.log10(values[-1]), num=num)
    indices = []
    i = 0
    j = 0
    while i < len(values) and j < len(desired_values):
        if desired_values[j] > values[i]:
            i += 1
        else:
            indices.append(i)
            j += 1
    # remove duplicates
    indices = [indices[0]] + [indices[i] for i in range(1, len(indices)) if indices[i] > indices[i - 1]]
    return indices


# ------------- MSD ------------------------------
def plot_msd():
    filename = "data/msd_v1.0.1-0_finite-6decades.npz"
    with np.load(filename) as data:
        times_noforce = data["times_noforce"]
        msd_noforce = data["msd_noforce"]
        std_dev_noforce = data["std_dev_noforce"]
        std_err_noforce = data["std_err_noforce"]

        times_force = data["times_force"]
        msd_force = data["msd_force"]
        std_dev_force = data["std_dev_force"]
        std_err_force = data["std_err_force"]

    do_logarithmic = True
    do_errorbars = False
    fit_reduced_diffusion = True
    num = 40
    if do_logarithmic:
        # indices = logarithmic_indices(1, len(times_noforce), num=num)
        indices = logarithmic_indices_of_uneven_values(times_noforce, num=num)
        print(indices)
    else:
        indices = linear_indices(0, len(times_noforce), num=num)

    interaction_distance = 1.26
    diffusion_coefficient = 1.
    time_units = interaction_distance ** 2 / diffusion_coefficient  # this is a choice!
    len_squ_units = interaction_distance ** 2

    plt.plot(times_noforce[indices] / time_units, 6. * times_noforce[indices] / time_units, label=r"$6 Dt$")

    if do_errorbars:
        plt.errorbar(times_noforce[indices] / time_units, msd_noforce[indices] / len_squ_units,
                     yerr=std_err_noforce[indices] / len_squ_units, fmt=".", label="Potential free")
        plt.errorbar(times_force[indices] / time_units, msd_force[indices] / len_squ_units,
                     yerr=std_err_force[indices] / len_squ_units, fmt=".", label="Harmonic repulsion")
    else:
        if fit_reduced_diffusion:
            times_fit = times_force[indices] / time_units
            msd_fit = msd_force[indices] / len_squ_units
            fit_indices = np.logical_and(1e-1 < times_fit, times_fit < 1e1)
            print(fit_indices)
            times_fit = times_fit[fit_indices]
            msd_fit = msd_fit[fit_indices]

            def f(t, d): return 6. * t * d

            popt, pcov = so.curve_fit(f, times_fit, msd_fit)
            g = lambda t: f(t, popt[0])
            print("fitted effective reduced diffusion {} D".format(popt[0]))
            fit_result_times = times_force[indices] / time_units
            fit_result_msd = g(fit_result_times)
            plt.plot(fit_result_times, fit_result_msd, "--", label=r"$D_\mathrm{reduced}=0.35 D$")

        plt.plot(times_noforce[indices] / time_units, msd_noforce[indices] / len_squ_units,
                 ".", label="Potential free")
        plt.plot(times_force[indices] / time_units, msd_force[indices] / len_squ_units,
                 "^", markersize=3, label="Harmonic repulsion")

    plt.legend(loc="upper left")
    plt.xlabel(r"Time $t/ (\sigma^2 D^{-1})$ ")
    plt.ylabel("Mean squared displacement\n" + r"$\langle (x(t) - x_0)^2 \rangle / \sigma^2$")

    if do_logarithmic:
        plt.xscale("log")
        plt.yscale("log")
        xmin, xmax = plt.xlim()
        # plt.xlim((1e-3, xmax))
        plt.tick_params(axis='x', which='minor')
    else:
        ax = plt.gca()
        ax.xaxis.set_minor_locator(ticker.AutoMinorLocator())
        ax.yaxis.set_minor_locator(ticker.AutoMinorLocator())

    fig = plt.gcf()
    fig.tight_layout()

    plt.savefig("plots/msd.pdf", bbox_inches="tight", transparent=True)
    # plt.show()
    plt.clf()


# ------------- Living polymer -------------------
def plot_living_polymer():
    n_realizations = 15
    filenames = ["data/polylen_{}.npz".format(i) for i in range(n_realizations)]
    # filename = "data/polylen_105-1234567.npz"
    n_beads = []
    n_beads_dev = []
    n_tops = []
    times = []
    for filename in filenames:
        with np.load(filename) as data:
            n_beads.append(data["number_of_beads"])
            n_beads_dev.append(data["number_of_beads_std_dev"])
            n_tops.append(data["number_of_topologies"])
            times.append(data["times"])

    assert np.all([len(times[0]) == len(t) for t in times])

    n_beads = np.array(n_beads)
    n_beads_dev = np.array(n_beads_dev)

    times = times[0]

    fro, to = 0, len(times) * 2 // 3
    times = times[fro:to]
    n_beads_mean = np.mean(n_beads, axis=0)[fro:to]

    num = 100
    indices = linear_indices(0, len(times), num=num)

    x = times[indices] / 1e5
    y = n_beads_mean[indices]
    # dev = np.mean(n_beads_dev)[indices]
    dev = np.std(n_beads, axis=0)[indices]
    lower = y - dev
    lower[lower <= 2.] = 2.  # no polymer is shorter than 2
    upper = y + dev
    plt.fill_between(x, lower, upper, alpha=0.4)
    plt.plot(x, y)
    plt.xlabel(r"Time $t$ / a.u.")
    plt.ylabel("Mean number of beads\nin a polymer " + r"$\langle n(t) \rangle$")

    ax = plt.gca()
    ax.xaxis.set_minor_locator(ticker.AutoMinorLocator())
    ax.yaxis.set_minor_locator(ticker.AutoMinorLocator())

    fig = plt.gcf()
    fig.tight_layout()

    plt.savefig("plots/living_polymer.pdf", bbox_inches="tight", transparent=True)
    # plt.show()
    plt.clf()


# ------------- Cytosolic reactions -------------------

def plot_cytosolic():
    blue = "C0"
    orange = "C1"
    results_dir = "./data/cytosolic"
    dataframe = pd.DataFrame()
    for filename in os.listdir(results_dir):
        if "result" in filename:
            filepath = os.path.join(results_dir, filename)
            filedata = pd.read_hdf(filepath, "result")
            dataframe = dataframe.append(filedata)

    grouped = dataframe.groupby(["volume_occupation", "with_repulsion", "reaction_scheme"])

    t_t = grouped["times"].apply(lambda x: np.mean(x.values, axis=0))
    a_t = grouped["c_a"].apply(lambda x: np.mean(x.values, axis=0))
    da_t = grouped["c_a"].apply(lambda x: np.std(x.values, axis=0) / np.sqrt(len(x.values)))
    c_t = grouped["c_c"].apply(lambda x: np.mean(x.values, axis=0))
    dc_t = grouped["c_c"].apply(lambda x: np.std(x.values, axis=0) / np.sqrt(len(x.values)))

    def plot_timeseries(selector, color, label):
        t = t_t.loc[selector][indices]
        a = a_t.loc[selector][indices]
        da = da_t.loc[selector][indices]
        c = c_t.loc[selector][indices]
        dc = dc_t.loc[selector][indices]
        #plt.plot(t, a, linestyle="-", marker=".", label="A " + label, color=color, alpha=0.8)
        plt.plot(t, a, linestyle="-", label="A " + label, color=color)
        #plt.fill_between(t, a - da, a + da, alpha=0.3, color=color)
        #plt.plot(t, c, linestyle="-", marker="^", markersize=3, label="C " + label, color=color, alpha=0.8)
        plt.plot(t, c, linestyle=":", linewidth=2., label="C " + label, color=color)
        #plt.fill_between(t, c - dc, c + dc, alpha=0.3, color=color)

    def plot_ode_low():
        plt.plot(ode_times_low[ode_indices_low], ode_solution_low[:, 0][ode_indices_low], "k--", label="RRE")
        plt.plot(ode_times_low[ode_indices_low], ode_solution_low[:, 1][ode_indices_low], "k--")

    ode_times_low = (dataframe[dataframe["volume_occupation"] == 0.3])["ode_times"].iloc[0]
    ode_solution_low = (dataframe[dataframe["volume_occupation"] == 0.3])["ode_solution"].iloc[0]
    ode_indices_low = logarithmic_indices(0, len(ode_times_low), num=100)

    def plot_ode_high():
        plt.plot(ode_times_high[ode_indices_high], ode_solution_high[:, 0][ode_indices_high], "k--", label="RRE")
        plt.plot(ode_times_high[ode_indices_high], ode_solution_high[:, 1][ode_indices_high], "k--")

    ode_times_high = (dataframe[dataframe["volume_occupation"] == 0.6])["ode_times"].iloc[0]
    ode_solution_high = (dataframe[dataframe["volume_occupation"] == 0.6])["ode_solution"].iloc[0]
    ode_indices_high = logarithmic_indices(0, len(ode_times_high), num=100)

    any_times = dataframe["times"].iloc[0]
    indices = logarithmic_indices(0, len(any_times), num=100)

    fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(7.1, 6.2), sharex='col', sharey='row')

    plt.sca(ax1)
    plot_ode_low()
    plot_timeseries((0.3, False, 'Gillespie'), blue, "Doi")
    plot_timeseries((0.3, False, 'DetailedBalance'), orange, "DB")
    plt.title(r"\textbf{(a)} 30\% vol. occ.,"+"\nNo potential")
    plt.xscale("log")
    plt.legend(loc="best")
    plt.ylabel(r"Concentration / $\mathrm{nm}^{-3}$")
    plt.gca().yaxis.set_minor_locator(ticker.AutoMinorLocator())

    plt.sca(ax2)
    plot_ode_low()
    plot_timeseries((0.3, True, 'Gillespie'), blue, "Doi")
    plot_timeseries((0.3, True, 'DetailedBalance'), orange, "DB")
    plt.title(r"\textbf{(b)} 30\% vol. occ.,"+"\nHarmonic repulsion")
    plt.xscale("log")
    plt.legend(loc="best")
    plt.gca().yaxis.set_minor_locator(ticker.AutoMinorLocator())

    plt.sca(ax3)
    plot_ode_high()
    plot_timeseries((0.6, False, 'Gillespie'), blue, "Doi")
    plot_timeseries((0.6, False, 'DetailedBalance'), orange, "DB")
    plt.title(r"\textbf{(c)} 60\% vol. occ., "+"\nNo potential")
    plt.xscale("log")
    plt.legend(loc="best")
    plt.ylabel(r"Concentration / $\mathrm{nm}^{-3}$")
    plt.xlabel("Time / ns")
    plt.gca().yaxis.set_minor_locator(ticker.AutoMinorLocator())

    plt.sca(ax4)
    plot_ode_high()
    plot_timeseries((0.6, True, 'Gillespie'), blue, "Doi")
    plot_timeseries((0.6, True, 'DetailedBalance'), orange, "DB")
    plt.title(r"\textbf{(d)} 60\% vol. occ.,"+"\nHarmonic repulsion")
    plt.xscale("log")
    plt.legend(loc="best")
    plt.xlabel("Time / ns")
    plt.gca().yaxis.set_minor_locator(ticker.AutoMinorLocator())

    fig.tight_layout()
    plt.savefig("plots/cytosolic_reactions_timeseries.pdf", bbox_inches="tight", transparent=True)
    # plt.show()
    plt.clf()
    plt.close(fig)


if __name__ == '__main__':
    args = parser.parse_args()

    do_all = True
    for thing, do_thing in vars(args).items():
        if isinstance(do_thing, bool):
            do_all = do_all and not do_thing

    if do_all:
        plot_cytosolic()
        plot_living_polymer()
        plot_msd()
    else:
        if args.do_cytosolic:
            plot_cytosolic()
        if args.do_living_polymer:
            plot_living_polymer()
        if args.do_msd:
            plot_msd()
