import json

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

plt.style.use("../readdy_manuscript.mplstyle")



class Labeloffset():
    def __init__(self,  ax, label="", axis="y", postfix=""):
        self.axis = {"y":ax.yaxis, "x":ax.xaxis}[axis]
        self.label=label
        self.postfix = postfix
        ax.callbacks.connect(axis+'lim_changed', self.update)
        ax.figure.canvas.draw()
        self.update(None)

    def update(self, lim):
        fmt = self.axis.get_major_formatter()
        self.axis.offsetText.set_visible(False)
        self.axis.set_label_text(self.label + " 1"+ fmt.get_offset() + self.postfix )
def exp_tex(float_number):
    """
    Returns a string representation of the scientific
    notation of the given number formatted for use with
    LaTeX or Mathtext.
    """
    neg = False
    if float_number == 0.0:
        return r"$0.0"
    elif float_number < 0.0:
        neg = True

    exponent = np.floor(np.log10(abs(float_number)))
    mantissa = float_number/10**exponent
    if neg:
        mantissa = -mantissa
    mantissa_format = str(mantissa)[0:3]
    return "${0}\\times10^{{{1}}}$"\
           .format(mantissa_format, str(int(exponent)))

with open('cytosolic_reactions_jreaddy_arch_2.json', 'r') as f:
    jreaddy = json.load(f)

g = pd.read_hdf('performance_data_arch.h5', 'perfdata')

scpu = g.loc[lambda df: df.n_threads == -1, :]
cpu_1_thread = g.loc[lambda df: df.n_threads == 1, :]
cpu_4_threads = g.loc[lambda df: df.n_threads == 4, :]
cpu_6_threads = g.loc[lambda df: df.n_threads == 6, :]
cpu_7_threads = g.loc[lambda df: df.n_threads == 7, :]
cpu_8_threads = g.loc[lambda df: df.n_threads == 8, :]
cpu_12_threads = g.loc[lambda df: df.n_threads == 12, :]
# cpu_32_threads = g.loc[lambda df: df.n_threads ==32, :]

scpu_grouped = scpu.groupby('n_particles_a')
cpu1_grouped = cpu_1_thread.groupby('n_particles_a')
cpu4_grouped = cpu_4_threads.groupby('n_particles_a')
cpu6_grouped = cpu_6_threads.groupby('n_particles_a')
cpu7_grouped = cpu_7_threads.groupby('n_particles_a')
cpu8_grouped = cpu_8_threads.groupby('n_particles_a')
cpu12_grouped = cpu_12_threads.groupby('n_particles_a')
# cpu32_grouped = cpu_32_threads.groupby('n_particles_a')

from matplotlib.ticker import AutoMinorLocator

minorLocator = AutoMinorLocator(2)

f, ax = plt.subplots(1,1, figsize=(8, 6))
ax.ticklabel_format(style='sci', scilimits=(0,0))
ax.plot(jreaddy['n_particles_a'], np.array(jreaddy["t/particle/step"]), label="Java ReaDDy")
# ax.plot(scpu_grouped.groups.keys(), np.array(jreaddy['t/particle/step']), label="Java ReaDDy")
ax.plot(scpu_grouped.groups.keys(), scpu_grouped.mean()['time/particle/step'], label='Sequential kernel')
# ax.plot(cpu1_grouped.groups.keys(), cpu1_grouped.mean()['time/particle/step'], label='CPU at 1 thread')
# ax.plot(cpu4_grouped.groups.keys(), cpu4_grouped.mean()['time/particle/step'], label='CPU at 4 threads')
ax.plot(cpu6_grouped.groups.keys(), cpu6_grouped.mean()['time/particle/step'], label='Parallel kernel at 6 threads')
# ax.plot(cpu7_grouped.groups.keys(), cpu7_grouped.mean()['time/particle/step'], label='Parallel kernel at 7 threads')
ax.plot(cpu12_grouped.groups.keys(), cpu12_grouped.mean()['time/particle/step'], label='Parallel kernel at 12 threads')
# ax.plot(cpu32_grouped.groups.keys(), cpu32_grouped.mean()['time/particle/step'], label='Parallel kernel at 32 threads')
ax.set_xscale('log')
ax.yaxis.set_minor_locator(minorLocator)
ax.set_ylim([-.01e-5, .9e-5])
ax.yaxis.offsetText.set_visible(False)
ax.legend(loc="upper left")
lo = Labeloffset(ax, label="Computation time in", postfix='s', axis="y")
# ax.set_title('Computation time per particle per integration step')
ax.set_xlabel('Number of particles')
f.savefig("../../figures/performance/performance_over_nparticles.pdf", bbox_inches="tight", transparent=True)

last_cpu12_time = cpu12_grouped.mean()['time/particle/step'].values[-1]
last_cpu6_time = cpu6_grouped.mean()['time/particle/step'].values[-1]
last_n_particles = list(cpu12_grouped.groups.keys())[-1]
print("last cpu12: {}, last cpu6: {}".format(last_cpu12_time, last_cpu6_time))
print("cpu12 time is {} times faster than cpu6".format((last_cpu6_time / last_cpu12_time)))

