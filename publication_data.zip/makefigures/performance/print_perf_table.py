import json

import pandas as pd
from tabulate import tabulate

with open('cytosolic_reactions_jreaddy_arch.json', 'r') as f:
    jreaddy = json.load(f)

g = pd.read_hdf('performance_data_arch.h5', 'perfdata')

scpu = g.loc[lambda df: df.n_threads == -1, :]
cpu = g.loc[lambda df: df.n_threads > -1, :]

min_computation_time = {}

for N in cpu.n_particles_a.unique():
    cpu_n_particles = cpu.loc[lambda df: df.n_particles_a == N, :]
    amin = cpu_n_particles['computation_time'].idxmin()
    minnum = cpu_n_particles.loc[amin]
    min_computation_time[N] = minnum

scpu_grouped = scpu.groupby('n_particles_a')
cpu_gouped = cpu.groupby('n_particles_a')

scpu_mean = scpu_grouped.mean()
seconds_in_a_day = 86400.
steps_per_day_scpu_all = seconds_in_a_day / (scpu_mean['time/particle/step'] * scpu_mean['average_n_particles'])

result = []

approx_n = ["250", "1000", "13000", "40000"]
for i, key in enumerate([200, 700, 10000, 30000]):
    df_scpu = (scpu.loc[lambda df: df.n_particles_a == key]).mean()
    d = min_computation_time[key]
    steps_per_day = seconds_in_a_day / (d['time/particle/step'] * d["average_n_particles"])
    threads = d.n_threads
    steps_per_day_scpu = seconds_in_a_day / (df_scpu['time/particle/step'] * df_scpu['average_n_particles'])
    result.append([approx_n[i], steps_per_day_scpu, steps_per_day, threads])

print(tabulate(result, headers=['Approx N Particles', 'Steps/day SCPU', 'Steps/day CPU', '# Threads']))

