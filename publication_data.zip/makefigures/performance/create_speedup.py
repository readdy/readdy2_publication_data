import json

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

plt.style.use("../readdy_manuscript.mplstyle")



class Labeloffset():
    def __init__(self,  ax, label="", axis="y", postfix=""):
        self.axis = {"y":ax.yaxis, "x":ax.xaxis}[axis]
        self.label=label
        self.postfix = postfix
        ax.callbacks.connect(axis+'lim_changed', self.update)
        ax.figure.canvas.draw()
        self.update(None)

    def update(self, lim):
        fmt = self.axis.get_major_formatter()
        self.axis.offsetText.set_visible(False)
        self.axis.set_label_text(self.label + " 1"+ fmt.get_offset() + self.postfix )
def exp_tex(float_number):
    """
    Returns a string representation of the scientific
    notation of the given number formatted for use with
    LaTeX or Mathtext.
    """
    neg = False
    if float_number == 0.0:
        return r"$0.0"
    elif float_number < 0.0:
        neg = True

    exponent = np.floor(np.log10(abs(float_number)))
    mantissa = float_number/10**exponent
    if neg:
        mantissa = -mantissa
    mantissa_format = str(mantissa)[0:3]
    return "${0}\\times10^{{{1}}}$"\
           .format(mantissa_format, str(int(exponent)))

with open('cytosolic_reactions_jreaddy_seagull.json', 'r') as f:
    jreaddy = json.load(f)

g = pd.read_hdf('performance_data_arch.h5', 'perfdata')

scpu = g.loc[lambda df: df.n_threads == -1, :]
cpu_1_thread = g.loc[lambda df: df.n_threads == 1, :]
cpu_7_threads = g.loc[lambda df: df.n_threads == 7, :]
cpu_32_threads = g.loc[lambda df: df.n_threads ==32, :]

scpu_grouped = scpu.groupby('n_particles_a')
cpu1_grouped = cpu_1_thread.groupby('n_particles_a')
cpu7_grouped = cpu_7_threads.groupby('n_particles_a')
cpu32_grouped = cpu_32_threads.groupby('n_particles_a')

f, (ax1, ax2) = plt.subplots(2, 1, sharex=True, figsize=(6,4))

threads = np.unique(g.n_threads)[np.where(np.unique(g.n_threads) > 0)]
to_plot = [1000, 10000, 100000]
n_particles = [1300, 13000, 130000]
ix = 0
lines = []
labels = []
for n in np.unique(g.n_particles_a):
    if n in to_plot:
        label = r'$\sim$ {} particles'.format(n_particles[ix])
        
        df = g.loc[lambda df: df.n_particles_a == n, :]
        df_scpu = df.loc[lambda x: x.n_threads == -1]
        df_cpu = df.loc[lambda x: x.n_threads > -1].groupby('n_threads').mean()
        speedup = df_cpu.computation_time[1] / df_cpu.computation_time
        l = ax1.plot(threads, speedup)
        lines.append(l[0])
        labels.append(label)
        ax2.plot(threads, speedup / threads, color='C{}'.format(ix))
        ix += 1
l = ax1.plot(threads[:6], threads[:6], 'k--')
lines.append(l[0])
labels.append('optimum')
ax2.plot(threads, np.ones_like(threads), 'k--')
# loc='upper center', bbox_to_anchor=(0.5, 1.05),           ncol=3, fancybox=True, shadow=True
#ax1.legend(bbox_to_anchor=(.5, 0.), loc='lower center',
#           ncol=2, borderaxespad=0.)
ax1.set_xticks(threads)
ax1.grid(True)
ax1.set_ylabel(r'speedup')
ax2.grid(True)
ax2.set_ylabel(r'efficiency')
ax2.set_xlabel(r'threads')
ax2.set_ylim([.2, 1.15])
#ax1.set_title('Performance increase and efficiency over number of threads\n compared to single threaded')

f.subplots_adjust(hspace=0)
plt.setp([a.get_xticklabels() for a in f.axes[:-1]], visible=False)

ax2.legend(lines, labels, loc=(0.02, 0.05))

ax1.get_yaxis().set_label_coords(-0.09,0.5)
ax2.get_yaxis().set_label_coords(-0.09,0.5)

f.text(.13, .84, r"\textbf{(a)}")
f.text(.13, .455, r"\textbf{(b)}")

f.savefig("../../figures/performance/speedup.pdf", bbox_inches="tight", transparent=True)

