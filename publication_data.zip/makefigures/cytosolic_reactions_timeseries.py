#!/usr/bin/env python
# coding: utf-8

"""
We consider the system of particle species A, B and C that undergo reactions $A + B\rightleftharpoons C$ and also have optional volume exclusion
effects due to repulsive potentials between all particles. A and B Particles will be initially uniformly distributed in a periodic box and no C
particles are present.

We first demonstrate how the concentration of particles evolves in time and compares to a description by the law of mass action (LMA). This
demonstrates that ReaDDy produces exact results when parameters are in the well-mixed regime. We also show that including a repulsive potential
between all particles, but not changing the intrinsic reaction rates, will lead to different macroscopic reaction kinetics.

The focus of this demonstration is the measurement of computation time. In particular we observe the computation time $\tau$ per particle and per
 integration step. The system is simulated for different initial particle numbers, such that the density is constant.

Additionally here we want to compare the standard reaction model 'doi' and the new detailed-balance method 'db'

Parameters: if not further specified, units are nanometer, nanoseconds and kilojoule/mol
temperature:
  kT = 2.43614 kJ/mol (that is 293 Kelvin)
macroscopic rates:
  K_d = 0.0001309917227093789 per nanometer^3
  k_off = lambda_off = 5e-5 per nanosecond
  k_on = k_off / K_d = 0.3817035074111598 per nanosecond times nanometer^3
diffusion constants:
  D_A = 0.1431 nanometer^2 per nanosecond
  D_B = 0.0716 nanometer^2 per nanosecond
  D_C = 0.06882 nanometer^2 per nanosecond
apparent particle radii:
  r = {"A": 1.5, "B": 3., "C": 3.12}
  it holds $$ r_A^3 + r_B^3 = r_C^3 $$
sum of r_A and r_B is reaction radius R = 4.5
interaction radii R_{int,ij} are sums of radii r_i and r_j
force constant:
  kappa = 0 or 10 kJ/mol per nanometer^2


For both reaction schemes we derive the same lambda_on as described in DB paper, that would yield the macro/LMA behavior in a dilute system.
Thus we expect a different outcome of 'doi' and 'db' solely due to the high density of the system.

"""

import os
import numpy as np
import scipy.integrate as si
import argparse
import string
import time
import random
import pandas as pd
import readdy

parser = argparse.ArgumentParser()
parser.add_argument('out_dir', type=str)
parser.add_argument('reaction_scheme', type=str)
repulsion_parser = parser.add_mutually_exclusive_group(required=True)
repulsion_parser.add_argument('--repulsion', dest='with_repulsion', action='store_true')
repulsion_parser.add_argument('--no-repulsion', dest='with_repulsion', action='store_false')
parser.set_defaults(with_repulsion=False)
density_parser = parser.add_mutually_exclusive_group(required=True)
density_parser.add_argument('--low-density', dest='init_number', action='store_const', const=509)
density_parser.add_argument('--high-density', dest='init_number', action='store_const', const=1018)
parser.set_defaults(init_number=509)


def stamp(random_digits=8):
    """
    Generate a string based on the current date, time and an 8-digit
    random string, which shall be guarantee enough not to generate the same string twice
    """
    timestamp = time.strftime("%Y_%m_%d-%H_%M_%S")
    randomstamp = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(random_digits))
    _stamp = timestamp + "_" + randomstamp
    return _stamp


def harmonic_repulsion_energy(r, interaction_radius, force_const_ab):
    if r < interaction_radius:
        return 0.5 * force_const_ab * np.power(r - interaction_radius, 2.)
    else:
        return 0.


def integrand(r, interaction_radius, force_const_ab, kT):
    return 4. * np.pi * r * r * np.exp(-1. / kT * harmonic_repulsion_energy(r, interaction_radius, force_const_ab))


def calc_radius_grid(max_radius):
    return np.linspace(0., max_radius, 1000, dtype=float)


def calc_effective_interaction_volume(interaction_radius, force_const_ab, kT):
    radius_grid = calc_radius_grid(interaction_radius)
    value_grid = np.fromiter(map(lambda r: integrand(r, interaction_radius, force_const_ab, kT), radius_grid),
                             dtype=float)
    result = si.simps(y=value_grid, x=radius_grid)
    return result


def calc_effective_reaction_volume(reaction_radius, interaction_radius, force_const_ab, kT):
    radius_grid = calc_radius_grid(reaction_radius)
    value_grid = np.fromiter(map(lambda r: integrand(r, interaction_radius, force_const_ab, kT), radius_grid),
                             dtype=float)
    result = si.simps(y=value_grid, x=radius_grid)
    return result


# according to formula in db manuscript
def calc_intrinsic_on_rate(l_off, K_d, volume, interaction_volume, effective_interaction_volume,
                           effective_reaction_volume):
    result = l_off * (volume - interaction_volume + effective_interaction_volume)
    result /= K_d * volume * effective_reaction_volume
    return result


def get_system():
    system = readdy.ReactionDiffusionSystem(
        box_size=[box_length, box_length, box_length],
        temperature=293.,
        unit_system={"length_unit": "nanometer", "time_unit": "nanosecond", "energy_unit": "kilojoule / mol"}
    )

    system.add_species("A", diffusion_constant=diffusion_coeffs["A"] * ut.nanometer ** 2 / ut.nanosecond)
    system.add_species("B", diffusion_constant=diffusion_coeffs["B"] * ut.nanometer ** 2 / ut.nanosecond)
    system.add_species("C", diffusion_constant=diffusion_coeffs["C"] * ut.nanometer ** 2 / ut.nanosecond)

    current_force_constant = force_const * ut.kilojoule / ut.mol / (ut.nanometer ** 2)
    if current_force_constant.magnitude > 0.:
        all_pairs = [("A", "A"), ("B", "B"), ("C", "C"), ("A", "B"), ("A", "C"), ("B", "C")]
        for pair in all_pairs:
            distance = particle_radii[pair[0]] + particle_radii[pair[1]]
            system.potentials.add_harmonic_repulsion(pair[0], pair[1], current_force_constant,
                                                     interaction_distance=distance)
    return system


def configure_reactions(system):
    system.reactions.add_fusion("fusion", "A", "B", "C",
                                rate=lambda_on / ut.nanosecond,
                                educt_distance=reaction_radius * ut.nanometer)
    system.reactions.add_fission("fission", "C", "A", "B",
                                 rate=lambda_off / ut.nanosecond,
                                 product_distance=reaction_radius * ut.nanometer)


def generate_ode_solution():
    from scipy.integrate import odeint

    def f(x, _):
        result = np.zeros_like(x)
        delta = - k_on * x[0] * x[0] + k_off * x[1]
        result[0] = delta
        result[1] = -1. * delta
        return result

    x_init = np.array([number_a, 0.]) / volume
    final_time = n_steps * timestep
    ode_times = np.arange(0., final_time, 1.)  # in nanoseconds
    ode_solution = odeint(f, x_init, t=ode_times)
    return ode_times, ode_solution


def simulate():
    # @todo equilibrate before reacting
    # system
    system = get_system()
    configure_reactions(system)

    # simulation
    simulation = system.simulation("SingleCPU")
    simulation.reaction_handler = reaction_scheme
    simulation.progress_output_stride = 100
    simulation.show_progress = True

    simulation.output_file = os.path.join(out_dir, "trajectory_" + id + ".h5")
    simulation.observe.number_of_particles(stride=n_steps // 10000, types=["A", "B", "C"])
    # simulation.record_trajectory(n_steps // 50)

    initial_positions_a = np.random.random(size=(number_a, 3)) * box_length - .5 * box_length
    initial_positions_b = np.random.random(size=(number_b, 3)) * box_length - .5 * box_length
    simulation.add_particles("A", initial_positions_a)
    simulation.add_particles("B", initial_positions_b)

    if os.path.exists(simulation.output_file):
        os.remove(simulation.output_file)

    simulation.run(n_steps=n_steps, timestep=timestep)

    traj = readdy.Trajectory(simulation.output_file)
    times, counts = traj.read_observable_number_of_particles()
    times = times * timestep
    concentrations = counts / volume

    ode_times, ode_solution = generate_ode_solution()

    return times, concentrations, ode_times, ode_solution


if __name__ == '__main__':
    args = parser.parse_args()
    out_dir = args.out_dir # trajectory files and result files will go there

    reaction_scheme = args.reaction_scheme
    if reaction_scheme not in ["Gillespie", "UncontrolledApproximation", "DetailedBalance"]:
        raise ValueError("Invalid reaction scheme")

    with_repulsion = args.with_repulsion

    init_number = args.init_number
    volume_occupation = None
    if init_number == 509:
        volume_occupation = 0.3
    elif init_number == 1018:
        volume_occupation = 0.6
    else:
        raise ValueError("Invalid initial number of particles")

    # general parameters
    n_steps = 300000  #
    timestep = 0.1  # nanosecond
    number_a = init_number
    number_b = init_number
    kbt = 2.43614  # kJ/mol
    particle_radii = {"A": 1.5, "B": 3., "C": 3.12}  # in nanometers
    diffusion_coeffs = {"A": 0.1431, "B": 0.0716, "C": 0.06882}  # in nanometers^2 per nanosecond

    # macro rates
    K_d = 0.0001309917227093789  # times nanometer^3 per nanosecond
    k_off = 5e-5  # per nanosecond
    k_on = k_off / K_d

    # calculate reaction/interaction volumina and finally lambda_on
    box_length = 60.
    reaction_radius = particle_radii["A"] + particle_radii["B"]
    interaction_radius = reaction_radius
    volume = box_length ** 3
    force_const = 10. if with_repulsion else 0.
    interaction_volume = 4. / 3. * np.pi * reaction_radius ** 3
    effective_interaction_volume = calc_effective_interaction_volume(interaction_radius, force_const, kbt)
    effective_reaction_volume = calc_effective_reaction_volume(reaction_radius, interaction_radius, force_const, kbt)

    lambda_on = calc_intrinsic_on_rate(k_off, K_d, volume, interaction_volume, effective_interaction_volume,
                                       effective_reaction_volume)
    lambda_off = k_off

    print("lambda_on={}, lambda_off={}".format(lambda_on, lambda_off))

    # readdy simulation
    ut = readdy.units
    print("readdy.__version__ = ", readdy.__version__)

    id = stamp()

    times, concentrations, ode_times, ode_solution = simulate()

    result_file_path = os.path.join(out_dir, "result_" + id + ".h5")
    # result data is a one-element list (one row) of json/dict-labelled data items
    result_data = [{
        # arguments
        "volume_occupation": volume_occupation, "with_repulsion": with_repulsion, "reaction_scheme": reaction_scheme,
        # main results
        "c_a": concentrations[:, 0], "c_b": concentrations[:, 1], "c_c": concentrations[:, 2],
        "times": times, "ode_times": ode_times, "ode_solution": ode_solution,
        # other stuff
        "length_unit": "nanometer", "time_unit": "nanosecond", "energy_unit": "kJ/mol",
        "lambda_on": lambda_on, "lambda_off": lambda_off, "volume": volume, "kbt": kbt,
        "K_d": K_d, "k_off": k_off, "k_on": k_on, "force_const": force_const, "interaction_radius": interaction_radius,
        "reaction_radius": reaction_radius, "box_length": box_length, "n_steps": n_steps, "timestep": timestep,
        "init_number_a": number_a, "init_number_b": number_b, "init_number_c": 0, "diffusion_coeffs": diffusion_coeffs,
        "particle_radii": particle_radii
    }]
    dataframe = pd.DataFrame(result_data)

    dataframe.to_hdf(result_file_path, "result")

    #np.savez(result_file_path,
    #         c_a=concentrations[:, 0], c_b=concentrations[:, 1], c_c=concentrations[:, 2], times=times,
    #         ode_times=ode_times, ode_solution=ode_solution)

    import matplotlib.pyplot as plt

    plt.plot(times, concentrations[:, 0], label="[A]=[B]")
    plt.plot(times, concentrations[:, 2], label="[C]")
    plt.plot(ode_times, ode_solution[:, 0], "k--", label="law of mass action")
    plt.plot(ode_times, ode_solution[:, 1], "k--")
    plt.legend(loc="best")
    plt.xlabel(r"Time in $\mathrm{ns}$")
    plt.ylabel(r"Concentration in $\mathrm{nm}^{-3}$")
    # plt.show()
    plt.clf()
