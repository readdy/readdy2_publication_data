#!/bin/bash

START=$(date +%s.%N)

sleep 2.124

END=$(date +%s.%N)
DIFF=$(echo "$END - $START" | bc)

echo "It took $DIFF seconds"

