import json
import os
import shutil
import subprocess
import tempfile

import numpy as np
import tqdm


class JReaddyInput(object):

    def __init__(self):
        with open("input/in_copyNumbers.csv", 'r') as f:
            self.in_copynumbers = f.read()
        with open("input/param_global.xml", 'r') as f:
            self.param_global = f.read()
        with open("input/tplgy_potentials.xml", 'r') as f:
            self.tplgy_potentials = f.read()
        self.aux_files = ["param_groups.xml", "param_particles.xml", "param_reactions.xml",
                          "tplgy_coordinates.xml", "tplgy_coordinates.xyz", "tplgy_groups.xml"]
        self.aux_content = []
        for aux in self.aux_files:
            with open(os.path.join("input", aux), 'r') as f:
                self.aux_content.append(f.read())

    def write_copy_numbers(self, out, n_a, n_b, n_c):
        replaced = self.in_copynumbers.replace('[[A]]', str(int(n_a))).replace('[[B]]', str(int(n_b))).replace('[[C]]', str(int(n_c)))
        with open(os.path.join(out, 'in_copyNumbers.csv'), 'w') as f:
            f.write(replaced)

    def write_param_global(self, out, lattice_bounds):
        lattice_bounds_str = ';'.join("[{},{}]".format(int(x[0]), int(x[1])) for x in lattice_bounds)
        replaced = self.param_global.replace("<latticeBounds/>",
                                             "<latticeBounds>[{}]</latticeBounds>".format(lattice_bounds_str))
        replaced = replaced.replace("<outputFile>out_particleNumbers.csv</outputFile>",
                                    "<outputFile>{}</outputFile>".format("out_particleNumbers.csv"))
        with open(os.path.join(out, 'param_global.xml'), 'w') as f:
            f.write(replaced)

    def write_tplgy_potentials(self, out, origin, extent):
        replaced = self.tplgy_potentials.replace("origin=\"\"", "origin=\"{}\"".format(origin)) \
            .replace("extension=\"\"", "extension=\"{}\"".format(extent))
        with open(os.path.join(out, 'tplgy_potentials.xml'), 'w') as f:
            f.write(replaced)

    def write_aux_files(self, out):
        for aux, content in zip(self.aux_files, self.aux_content):
            with open(os.path.join(out, aux), 'w') as f:
                f.write(content)


class JReaddyRunner(object):

    def __init__(self, n_particles_a):
        self.n_particles_a = n_particles_a
        self.n_particles_b = n_particles_a
        # number of particles per nanometer**3
        self.desired_a_density = 2357. / 1e6
        self.edge_length = (n_particles_a / self.desired_a_density) ** (1. / 3.)
        self.sim_box_edge_length = np.ceil(self.edge_length + 15)
        self.lattice_bounds = [[-(self.sim_box_edge_length // 2), (self.sim_box_edge_length // 2)] for _ in range(3)]
        self.potential_origin = [-.5 * self.edge_length for _ in range(3)]
        self.potential_extent = [self.edge_length for _ in range(3)]

        self.n_particles_c = self.n_particles_a * 2 // 3
        self.n_particles_a_actual = self.n_particles_a - self.n_particles_c
        self.n_particles_b = self.n_particles_a_actual

        self.tmpdir = None
        self.outdir = None

    def __enter__(self):
        self.tmpdir = tempfile.mkdtemp("jreaddy")
        self.outdir = tempfile.mkdtemp("jreaddy_out")

        input = JReaddyInput()
        input.write_copy_numbers(self.tmpdir, self.n_particles_a_actual, self.n_particles_b, self.n_particles_c)
        input.write_param_global(self.tmpdir, self.lattice_bounds)
        input.write_tplgy_potentials(self.tmpdir, self.potential_origin, self.potential_extent)
        input.write_aux_files(self.tmpdir)

        return self

    def run(self):
        if self.tmpdir is None:
            raise RuntimeError("should only be called in context manager")
        out = subprocess.run([os.path.join(os.getcwd(), "run.sh"), str(self.tmpdir), str(self.outdir)],
                             stdout=subprocess.PIPE)
        out = out.stdout.decode('utf-8')
        #print(out)
        time_begin = "It took "
        time_end = " seconds"
        elapsed = float(out[out.find(time_begin) + len(time_begin):out.find(time_end)])

        # this is some weird shit
        self.outcsv = str(os.path.join(self.outdir, 'out_particleNumbers.csv')).replace("/", '')[3:]
        X = np.loadtxt(os.path.join('/tmp/', self.outcsv), skiprows=3, delimiter=",")
        t = X[:, 0]
        n_a = X[:, 1]
        n_b = X[:, 2]
        n_c = X[:, 3]
        n_frames = float(len(t))
        time_per_step = elapsed / n_frames
        avg_particles = np.sum(n_a + n_b + n_c) / n_frames
        time_per_particle_per_step = elapsed / avg_particles / n_frames

        return {
            'elapsed': elapsed,
            'avg_n_particles': avg_particles,
            'n_steps': 3000,
            't/step': time_per_step,
            't/particle/step': time_per_particle_per_step
        }

    def __exit__(self, exc_type, exc_val, exc_tb):
        shutil.rmtree(self.tmpdir, ignore_errors=True)
        shutil.rmtree(self.outdir, ignore_errors=True)
        shutil.rmtree(self.outcsv, ignore_errors=True)

        self.tmpdir = None
        self.outdir = None


if __name__ == '__main__':

    result = {
        'n_particles_a': [],
        'average_n_particles': [],
        't': [],
        't/step': [],
        't/particle/step': [],
        'n_steps': 3000
    }
    
    n_a_particles = np.ceil(np.hstack(([200, 300, 400, 500, 600, 700, 800, 900], np.logspace(3, 5, num=20)))) #np.ceil(np.hstack(([200], np.logspace(2, 5, num=20)[3:])))

    # n_a_particles = [200, 400, 700]
    for n in tqdm.tqdm(n_a_particles, desc="n_a_particles", total=len(n_a_particles)):
        with JReaddyRunner(n) as r:
            X = r.run()
            result['n_particles_a'].append(r.n_particles_a)
            result['average_n_particles'].append(X['avg_n_particles'])
            result['t'].append(X['elapsed'])
            result['t/step'].append(X['t/step'])
            result['t/particle/step'].append(X['t/particle/step'])

        j = json.dumps(result)
        with open('performance.json', 'w') as f:
            f.write(j)
