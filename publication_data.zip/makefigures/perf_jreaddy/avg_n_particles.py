#!/usr/bin/env python

import numpy as np

d = np.loadtxt("output/out_particleNumbers.csv", skiprows=3, delimiter=",")

n_steps = len(d)
all_particles = d[:,1] + d[:,2] + d[:,3]
avg_particles = np.sum(all_particles) / float(n_steps)

print("average number of particles {}".format(avg_particles))

