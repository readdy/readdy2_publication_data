import os
import numpy as np

initial_n_a = [200, 400, 700, 1000, 2357, 5000, 10000, 15000, 20000, 30000]
times = [2.96, 5.76, 9.69, 13.95, 50.44, 111.88, 264.04, 433.61, 615.71, 966.71]

folders = ["run_{}".format(n) for n in initial_n_a]

average_n_particles = []
t_per_step = []
t_per_particle_per_step = []
n_steps = None
for n, f, time in zip(initial_n_a, folders, times):
    outcsv = os.path.join(f, "outout_particleNumbers.csv")
    X = np.loadtxt(outcsv, skiprows=3, delimiter=",")
    t = X[:, 0]
    n_a = X[:, 1]
    n_b = X[:, 2]
    n_c = X[:, 3]
    n_frames = float(len(t))
    time_per_step = time / n_frames
    avg_particles = np.sum(n_a + n_b + n_c) / n_frames
    time_per_particle_per_step = time / avg_particles / n_frames
    assert n_steps is None or n_steps == n_frames
    n_steps = n_frames
    average_n_particles.append(avg_particles)
    t_per_step.append(time_per_step)
    t_per_particle_per_step.append(time_per_particle_per_step)

print("{")
print("\t\"average_n_particles\": {},".format(average_n_particles))
print("\t\"t\": {},".format(times))
print("\t\"t/step\": {},".format(t_per_step))
print("\t\"t/particle/step\": {},".format(t_per_particle_per_step))
print("\t\"n_steps\": {}".format(n_steps))
print("}")
