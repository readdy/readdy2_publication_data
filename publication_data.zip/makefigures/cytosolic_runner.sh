#!/usr/bin/zsh

outdir="./data/cytosolic"

# depending if it's ts or tsp
alias taskspooler=ts

for x in $(seq 1 10); do
    taskspooler ./cytosolic_reactions_timeseries.py --no-repulsion --high-density $outdir Gillespie ;
    taskspooler ./cytosolic_reactions_timeseries.py --no-repulsion --high-density $outdir DetailedBalance ;
    taskspooler ./cytosolic_reactions_timeseries.py --repulsion --high-density $outdir Gillespie ;
    taskspooler ./cytosolic_reactions_timeseries.py --repulsion --high-density $outdir DetailedBalance ;
    taskspooler ./cytosolic_reactions_timeseries.py --no-repulsion --low-density $outdir Gillespie ;
    taskspooler ./cytosolic_reactions_timeseries.py --no-repulsion --low-density $outdir DetailedBalance ;
    taskspooler ./cytosolic_reactions_timeseries.py --repulsion --low-density $outdir Gillespie ;
    taskspooler ./cytosolic_reactions_timeseries.py --repulsion --low-density $outdir DetailedBalance ;
done

