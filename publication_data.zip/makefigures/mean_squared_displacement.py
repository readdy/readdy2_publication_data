#!/usr/bin/env python
# coding: utf-8

import os
import numpy as np
import matplotlib.pyplot as plt

import readdy

print(readdy.__version__)


def simulate_msd(forces=False, timestep=1e-3, boxlength=12., walls=False):
    system = readdy.ReactionDiffusionSystem(
        box_size=(boxlength, boxlength, boxlength), periodic_boundary_conditions=[True, True, True], unit_system=None)
    system.add_species("A", 1.0)
    origin = np.array([-boxlength/2., -boxlength/2., -boxlength/2.]) + 1.
    extent = np.array([boxlength, boxlength, boxlength]) - 2.
    if walls:
        system.potentials.add_box("A", 50., origin=origin, extent=extent)
    if forces:
        # volume occupation of ~84% with this potential
        system.potentials.add_harmonic_repulsion("A", "A", force_constant=50., interaction_distance=1.26)

    desired_density = 800. / 10**3
    n_particles = int(desired_density * np.product(extent))
    print("Using n_particles={}".format(n_particles))

    # equilibrate
    simulation = system.simulation(kernel="CPU")
    init_pos = np.random.uniform(size=(n_particles, 3)) * extent[0] + origin[0]
    simulation.add_particles("A", init_pos)
    pos = None

    def pos_callback(x):
        nonlocal pos
        n = len(x)
        pos = np.zeros((n, 3))
        for i in range(n):
            pos[i][0] = x[i][0]
            pos[i][1] = x[i][1]
            pos[i][2] = x[i][2]
        print("saved positions")

    simulation.observe.particle_positions(stride=1000, callback=pos_callback)

    simulation.run(n_steps=10000, timestep=timestep, show_system=True)

    init_pos = np.copy(pos)

    # measure
    all_positions = None
    all_times = None
    decades = [10, 100, 1000, 10000, 100000, 300000, 1000000]
    for i, decade in enumerate(decades):
        print("Performing measure for decade={}".format(decade))
        simulation = system.simulation(kernel="CPU")

        simulation.output_file = "data/out_msd.h5"
        current_stride = (decade//1000) if decade >= 1000 else 1
        simulation.observe.particle_positions(stride=current_stride)
        simulation.add_particles("A", pos)

        if os.path.exists(simulation.output_file):
            os.remove(simulation.output_file)

        simulation.run(n_steps=decade, timestep=timestep, show_system=True)

        # get data
        traj = readdy.Trajectory(simulation.output_file)
        times, positions = traj.read_observable_particle_positions()
        #times, types, ids, positions = traj.read_observable_particles()
        #print("ids", ids)
        # sort positions wrt to ids in every timestep
        #for t in range(len(ids)):
        #    positions[t] = [x for _, x in sorted(zip(ids[t], positions[t]), key=lambda pair: pair[0])]

        times = np.array(times) * timestep

        # remove last positions (will be recorded in the next iteration at t=0) and use as new initial positions
        pos = positions[-1]
        pos = np.array([[x[0], x[1], x[2]] for x in pos])

        print(all_times)
        print(times)
        # append data
        if all_times is None:
            all_times = np.copy(times[0:-1])
        else:
            previous_stride_time = ((decades[i-1]//1000) if decade >= 1000 else 1) * timestep
            all_times = np.concatenate((all_times, times[0:-1] + all_times[-1] + previous_stride_time))

        if all_positions is None:
            all_positions = np.copy(positions[0:-1])
        else:
            all_positions = np.concatenate((all_positions, positions[0:-1]))

    return all_times, all_positions, init_pos


def get_wrapped_msd(positions, init_pos, box_size, do_wrap=True):
    import time
    t1 = time.perf_counter()
    # convert to pure numpy array to make use of fancy operations
    T = len(positions)
    hundredth = (T // 100) if T > 100 else 1
    N = len(positions[0])
    pos = np.zeros(shape=(T, N, 3))
    for t in range(T):
        if t % hundredth == 0:
            elapsed = time.perf_counter() - t1
            percentage = t / hundredth
            print(percentage, "/", 100, "\t", elapsed, "/", elapsed / (percentage if percentage > 0. else 0.000000001) * 100, "seconds")

        for n in range(N):
            pos[t, n, 0] = positions[t][n][0]
            pos[t, n, 1] = positions[t][n][1]
            pos[t, n, 2] = positions[t][n][2]

    t2 = time.perf_counter()
    print("Converting took {} seconds".format(t2-t1))
    if do_wrap:
        # Wrap the trajectories back to account for periodic boundaries
        # 1. find the box index of each point in time for each particle and each coordinate
        # 2. wrap the trajectory back to absolute positions for each particle using the box indices
        box_indices = np.zeros(shape=(T, N, 3), dtype=int)
        for t in range(1, T):
            for n in range(N):
                for coord in [0, 1, 2]:
                    delta = pos[t, n, coord] - pos[t - 1, n, coord]
                    if delta > 0.5 * box_size:
                        box_indices[t, n, coord] = box_indices[t - 1, n, coord] - 1
                    elif delta < - 0.5 * box_size:
                        box_indices[t, n, coord] = box_indices[t - 1, n, coord] + 1
                    else:
                        box_indices[t, n, coord] = box_indices[t - 1, n, coord]

        wrapped_pos = np.zeros_like(pos)
        for t in range(T):
            for n in range(N):
                wrapped_pos[t, n] = pos[t, n] + box_indices[t, n].astype(float) * box_size

        pos = wrapped_pos

    difference = pos - init_pos
    squared_displacements = np.sum(difference * difference, axis=2)  # sum over coordinates, per particle per timestep
    squared_displacements = squared_displacements.transpose()  # T x N -> N x T

    mean = np.mean(squared_displacements, axis=0)
    std_dev = np.std(squared_displacements, axis=0)
    std_err = np.std(squared_displacements, axis=0) / np.sqrt(len(squared_displacements))

    return mean, std_dev, std_err


length = 28.
times1, positions1, init_pos1 = simulate_msd(forces=False, boxlength=length, walls=True)
mean1, std_dev1, std_err1 = get_wrapped_msd(positions1, init_pos1, length, do_wrap=False)

times2, positions2, init_pos2 = simulate_msd(forces=True, boxlength=length, walls=True)
mean2, std_dev2, std_err2 = get_wrapped_msd(positions2, init_pos2, length, do_wrap=False)

stride = 1
plt.errorbar(times1[::stride], mean1[::stride], yerr=std_err1[::stride], fmt=".", label="potential free")
plt.errorbar(times2[::stride], mean2[::stride], yerr=std_err2[::stride], fmt=".", label="harmonic repulsion")
plt.plot(times1[::stride], 6. * times1[::stride], label=r"$6 D t$")
plt.legend(loc="best")
plt.xlabel(r"Time $t$")
plt.ylabel(r"Mean squared displacement $\langle (x(t) - x_0)^2 \rangle_N$")
plt.xscale("log")
plt.yscale("log")
plt.show()
#plt.clf()

np.savez("data/msd_" + readdy.__version__,
         times_noforce=times1, msd_noforce=mean1, std_dev_noforce=std_dev1, std_err_noforce=std_err1,
         times_force=times2, msd_force=mean2, std_dev_force=std_dev2, std_err_force=std_err2)
